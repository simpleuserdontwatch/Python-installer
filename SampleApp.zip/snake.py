import pygame,random,os
path = os.path.dirname(os.path.abspath(__file__)) + '\\'
pygame.init()
screen = pygame.display.set_mode((240,240))
pygame.display.set_caption('Snake')
headxy = [20,20]
foodxy=[random.randrange(0,221,20),random.randrange(0,221,20)]
black        = (0,0,0)
white       = (255,255,255)
segments = []
red = pygame.image.load(path + "red.png").convert()
green = pygame.image.load(path + "green.png").convert()
bg = pygame.image.load(path + "spaec.jpg").convert()
my_font = pygame.font.SysFont(path + 'ARIAL.TTF', 25)
length=0
dir = 0
sc = 0
died = False
clock = pygame.time.Clock()
def mainloop():
	global headxy, foodxy
	if dir == 0:
		headxy[0]+=20
	elif dir == 1:
		headxy[0]-=20
	elif dir == 2:
		headxy[1]-=20
	elif dir == 3:
		headxy[1]+=20
running = True
retry = True
while retry and running:
        died = False
        while running:
                screen.blit(bg,(0,0))
                keys_pressed = pygame.key.get_pressed()
                if keys_pressed[pygame.K_LEFT]:
                        if dir != 0:
                                dir = 1
                if keys_pressed[pygame.K_RIGHT]:
                        if dir != 1:
                                dir = 0
                if keys_pressed[pygame.K_UP]:
                        if dir != 3:
                                dir = 2
                if keys_pressed[pygame.K_DOWN]:
                        if dir != 2:
                                dir = 3
                if headxy[0]>220 or headxy[0]<0 or headxy[1]>220 or headxy[1]<0:
                        died = True
                screen.blit(red,tuple(foodxy))
                for i in segments:
                        screen.blit(green,tuple(i))
                if tuple(headxy) in segments:
                        died = True
                if foodxy == headxy or tuple(foodxy) in segments:
                        foodxy=[random.randrange(0,221,20),random.randrange(0,221,20)]
                        length+=1
                if len(segments) > length+1:
                        del segments[0]
                screen.blit(green,tuple(headxy))
                if sc > 22:
                        segments.append(tuple(headxy))
                        mainloop()
                        sc=0
                for e in pygame.event.get():
                        if e.type == pygame.QUIT:
                                running = False
                score = my_font.render('Score: '+str(length), False, white)
                screen.blit(score,(0,0))
                pygame.display.flip()
                if died:
                        break
                sc+=1
                clock.tick(128)
        while running and died:
                screen.fill(black)
                screen.blit(bg,(0,0))
                screen.blit(score,(120-(len('Score: '+str(length))*7),120-15))
                deadmessage = my_font.render('You died.', False, white)
                screen.blit(deadmessage,(0,0))
                deadmessage2 = my_font.render('Press enter to retry', False, white)
                screen.blit(deadmessage2,(0,200))
                for e in pygame.event.get():
                        if e.type == pygame.QUIT:
                                running = False
                                retry = False
                        if e.type == pygame.KEYDOWN:
                                if e.key == pygame.K_RETURN:
                                        died = False
                                        headxy = [20,20]
                                        length = 0
                                        dir=0
                                        foodxy=[random.randrange(0,221,20),random.randrange(0,221,20)]
                pygame.display.flip()
                clock.tick(60)
pygame.quit()
